
pg8000
------

pg8000 is a Pure-Python interface to the PostgreSQL database engine.  It is one of many PostgreSQL interfaces for the Python programming language. pg8000 is somewhat distinctive in that it is written entirely in Python and does not rely on any external libraries (such as a compiled python module, or PostgreSQL's libpq library). pg8000 supports the standard Python DB-API version 2.0.

pg8000's name comes from the belief that it is probably about the 8000th PostgreSQL interface for Python.

